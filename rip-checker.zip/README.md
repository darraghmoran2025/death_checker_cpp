# Rip.ie Client Status Checker

A command-line tool that reads a CSV of client records and checks each person against [Rip.ie](https://rip.ie) death notices, returning **Alive**, **Deceased**, or **Data Not Found** for each client.

---

## Requirements

- Windows 10 / 11
- The following files must all be in the same folder:
  - `rip_checker.exe`
  - `libcurl.dll`
  - `zlib1.dll`

---

## How to Run

1. Open **Command Prompt** (`Win + R` → type `cmd` → press Enter)
2. Navigate to the folder:
   ```cmd
   cd C:\Users\darra\rip-checker
   ```
3. Run the tool:
   ```cmd
   rip_checker.exe your_clients.csv
   ```

The easiest way to provide the file path is to type `rip_checker.exe ` and then **drag and drop** your CSV file into the Command Prompt window — it fills in the full path automatically.

---

## CSV Format

Your input CSV must have the following columns (column names are case-insensitive):

| Column | Required | Notes |
|--------|----------|-------|
| `ClientID` | No | Any reference number |
| `FirstName` | Yes | First name of client |
| `LastName` | Yes | Surname — maiden names in brackets are handled e.g. `Smith (née Jones)` |
| `County` | No | Irish county — improves accuracy, e.g. `Dublin`, `Cork`, `Co. Mayo` |

**Example:**
```csv
ClientID,FirstName,LastName,County
1,John,Murphy,Dublin
2,Patrick,Kelly,Galway
3,Michael,O'Brien,Cork
4,Thomas,Ryan,Tipperary
```

---

## Output

Results are saved automatically as `results_<yourfile>.csv` in the same folder as the tool.

The output adds two columns to your original data:

| Column | Description |
|--------|-------------|
| `Status` | `Alive`, `Deceased`, or `Data Not Found` |
| `Detail` | Notice date and location if deceased, or reason if not found |

**Example output:**
```csv
ClientID,FirstName,LastName,County,Status,Detail
1,John,Murphy,Dublin,Deceased,Death notice found | Notice date: 2025-11-03 | Location: Clontarf, Co. Dublin
2,Patrick,Kelly,Galway,Alive,No matching death notice found
```

---

## Optional Arguments

```cmd
rip_checker.exe clients.csv output.csv --rate 2000
```

| Argument | Description |
|----------|-------------|
| `output.csv` | Custom name for the results file |
| `--rate <ms>` | Delay between requests in milliseconds (default: 1500) |

---

## Notes

- **Male clients only** — the tool skips female death notices to avoid false matches
- **Maiden names** — if a surname contains `(née ...)`, the tool will also search under the maiden name
- **County mismatch** — if the county in your CSV differs from what is on Rip.ie, the tool will still find the notice and flag it as `county unverified`
- **Irish names** — fadas (á, é, í, ó, ú) are handled automatically, so `Sean` matches `Seán`
- **Coverage** — Rip.ie does not hold every death notice ever published; older or unpublished notices may not be found
- If you get `Error writing output`, close the results CSV in Excel before running again

---

## Building from Source

Requirements: Visual Studio Build Tools, CMake, vcpkg with `curl` installed.

```cmd
build.bat
```

This configures and builds the project, copying `rip_checker.exe` and the required DLLs to the project root.
