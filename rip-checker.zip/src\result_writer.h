#pragma once
#include <string>
#include <vector>
#include "csv_reader.h"
#include "rip_scraper.h"

struct OutputRecord {
    ClientRecord client;
    SearchResult result;
};

class ResultWriter {
public:
    explicit ResultWriter(const std::string& filepath);
    bool write(const std::vector<OutputRecord>& records, std::string& error);

    // Print a summary table to stdout
    static void printSummary(const std::vector<OutputRecord>& records);

private:
    std::string filepath_;
    std::string escapeField(const std::string& s);
    std::string statusToString(SearchStatus s);
};
