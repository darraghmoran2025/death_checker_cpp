#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include "csv_reader.h"
#include "rip_scraper.h"
#include "result_writer.h"

namespace fs = std::filesystem;

static void printUsage(const char* prog) {
    std::cout << "Usage:\n"
              << "  " << prog << " <input.csv> [output.csv] [--rate <ms>]\n\n"
              << "Arguments:\n"
              << "  input.csv    Client CSV with columns: ClientID, FirstName, LastName, County\n"
              << "  output.csv   Results file (default: results_<input>.csv)\n"
              << "  --rate <ms>  Delay between requests in ms (default: 1500)\n\n"
              << "CSV column names are detected automatically (case-insensitive).\n"
              << "Required columns: FirstName (or Forename), LastName (or Surname)\n"
              << "Optional columns: ClientID, County (or Address), DOB\n\n"
              << "Status values in output:\n"
              << "  Alive          - Searched OK, no death notice found\n"
              << "  Deceased       - Death notice found and location matches\n"
              << "  Data Not Found - Search failed or insufficient data\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }

    std::string input_path;
    std::string output_path;
    int rate_ms = 1500;

    // Parse arguments
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--rate" && i + 1 < argc) {
            rate_ms = std::stoi(argv[++i]);
        } else if (arg == "--help" || arg == "-h") {
            printUsage(argv[0]);
            return 0;
        } else if (input_path.empty()) {
            input_path = arg;
        } else if (output_path.empty()) {
            output_path = arg;
        }
    }

    // Default output filename: results_<inputstem>.csv
    if (output_path.empty()) {
        fs::path p(input_path);
        output_path = "results_" + p.stem().string() + ".csv";
    }

    std::cout << "=== Rip.ie Client Status Checker ===\n"
              << "Input:      " << input_path  << "\n"
              << "Output:     " << output_path << "\n"
              << "Rate limit: " << rate_ms << "ms between requests\n\n";

    // --- Read CSV ---
    CsvReader reader(input_path);
    std::vector<ClientRecord> clients;
    std::string err;

    if (!reader.read(clients, err)) {
        std::cerr << "Error reading CSV: " << err << "\n";
        return 1;
    }

    std::cout << "Loaded " << clients.size() << " client record(s).\n\n";

    // --- Process each client ---
    RipScraper scraper;
    scraper.setRateLimit(rate_ms);

    std::vector<OutputRecord> results;
    results.reserve(clients.size());

    int idx = 0;
    for (const auto& client : clients) {
        ++idx;
        std::cout << "[" << idx << "/" << clients.size() << "] "
                  << client.first_name << " " << client.last_name << "\n";

        SearchResult res = scraper.search(client.first_name, client.last_name, client.county);
        results.push_back({client, res});

        // Show immediate result
        std::string status;
        switch (res.status) {
            case SearchStatus::ALIVE:          status = "Alive";          break;
            case SearchStatus::DECEASED:       status = "Deceased";       break;
            case SearchStatus::DATA_NOT_FOUND: status = "Data Not Found"; break;
        }
        std::cout << "  -> " << status << ": " << res.detail << "\n";
    }

    // --- Print summary table ---
    ResultWriter::printSummary(results);

    // --- Write output CSV ---
    ResultWriter writer(output_path);
    if (!writer.write(results, err)) {
        std::cerr << "Error writing output: " << err << "\n";
        return 1;
    }

    std::cout << "Results saved to: " << output_path << "\n";
    return 0;
}
