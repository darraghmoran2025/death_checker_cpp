#include "csv_reader.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>

CsvReader::CsvReader(const std::string& filepath) : filepath_(filepath) {}

std::string CsvReader::trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n\"");
    size_t end   = s.find_last_not_of(" \t\r\n\"");
    return (start == std::string::npos) ? "" : s.substr(start, end - start + 1);
}

std::string CsvReader::toLower(const std::string& s) {
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(), ::tolower);
    return out;
}

// Handles quoted fields (e.g. "Smith, John")
std::vector<std::string> CsvReader::parseRow(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (in_quotes && i + 1 < line.size() && line[i + 1] == '"') {
                field += '"';
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            fields.push_back(trim(field));
            field.clear();
        } else {
            field += c;
        }
    }
    fields.push_back(trim(field));
    return fields;
}

// Find a column index by checking several candidate header names
int CsvReader::findColumn(const std::vector<std::string>& headers,
                          const std::vector<std::string>& candidates) {
    for (const auto& candidate : candidates) {
        for (size_t i = 0; i < headers.size(); ++i) {
            if (toLower(headers[i]) == toLower(candidate)) return static_cast<int>(i);
        }
    }
    return -1;
}

bool CsvReader::read(std::vector<ClientRecord>& records, std::string& error) {
    std::ifstream file(filepath_);
    if (!file.is_open()) {
        error = "Cannot open file: " + filepath_;
        return false;
    }

    std::string line;
    if (!std::getline(file, line)) {
        error = "CSV file is empty.";
        return false;
    }

    // --- Detect columns from header row ---
    auto headers = parseRow(line);

    int col_id    = findColumn(headers, {"clientid", "id", "client_id", "no", "ref"});
    int col_first = findColumn(headers, {"firstname", "first_name", "first name", "forename", "given name"});
    int col_last  = findColumn(headers, {"lastname", "last_name", "last name", "surname", "family name"});
    int col_county = findColumn(headers, {"county", "address", "location", "area", "region", "town"});
    int col_dob   = findColumn(headers, {"dob", "dateofbirth", "date_of_birth", "date of birth", "birthdate"});

    if (col_first < 0 || col_last < 0) {
        error = "CSV must have FirstName and LastName columns (or similar). "
                "Headers found: ";
        for (const auto& h : headers) error += "[" + h + "] ";
        return false;
    }

    int row = 1;
    while (std::getline(file, line)) {
        ++row;
        if (line.empty() || line.find_first_not_of(" ,\t\r\n") == std::string::npos)
            continue;

        auto fields = parseRow(line);

        ClientRecord rec;
        rec.row_number = row;

        auto get = [&](int col) -> std::string {
            return (col >= 0 && col < static_cast<int>(fields.size())) ? fields[col] : "";
        };

        rec.first_name    = get(col_first);
        rec.last_name     = get(col_last);
        rec.client_id     = (col_id >= 0) ? get(col_id) : std::to_string(row);
        rec.county        = get(col_county);
        rec.date_of_birth = get(col_dob);

        if (rec.first_name.empty() && rec.last_name.empty()) continue;

        records.push_back(rec);
    }

    if (records.empty()) {
        error = "No valid records found in CSV.";
        return false;
    }
    return true;
}
