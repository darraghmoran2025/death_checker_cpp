#pragma once
#include <string>
#include <vector>
#include <map>

struct ClientRecord {
    std::string client_id;
    std::string first_name;
    std::string last_name;
    std::string county;
    std::string date_of_birth;  // optional
    int row_number = 0;
};

class CsvReader {
public:
    explicit CsvReader(const std::string& filepath);
    bool read(std::vector<ClientRecord>& records, std::string& error);

private:
    std::string filepath_;
    std::vector<std::string> parseRow(const std::string& line);
    std::string trim(const std::string& s);
    std::string toLower(const std::string& s);
    int findColumn(const std::vector<std::string>& headers,
                   const std::vector<std::string>& candidates);
};
