#pragma once
#include <string>
#include <vector>

enum class SearchStatus {
    ALIVE,          // Searched OK, no match found
    DECEASED,       // Match found in death notices
    DATA_NOT_FOUND  // Search failed or insufficient data
};

struct SearchResult {
    SearchStatus status = SearchStatus::DATA_NOT_FOUND;
    std::string detail;         // Human-readable detail
    std::string match_name;     // Exact name found on Rip.ie
    std::string match_location; // Location from the notice
    std::string match_date;     // Notice publication date
};

class RipScraper {
public:
    RipScraper();
    ~RipScraper();

    // Main search: looks up first+last name, optionally narrows by county
    SearchResult search(const std::string& first_name,
                        const std::string& last_name,
                        const std::string& county = "");

    // Delay between requests in milliseconds (default: 1500ms)
    void setRateLimit(int ms) { rate_limit_ms_ = ms; }

private:
    int rate_limit_ms_ = 1500;

    std::string httpPost(const std::string& url, const std::string& body);
    std::string buildQuery(const std::string& surname, int page);
    std::string toLower(const std::string& s);
    std::string stripFadas(const std::string& s);   // á→a, é→e, í→i, ó→o, ú→u
    std::string normalizeCounty(const std::string& county);
    bool firstNameMatch(const std::string& client_fn, const std::string& notice_fn);
    bool isFemale(const std::string& firstname);

    static size_t writeCallback(void* contents, size_t size, size_t nmemb, std::string* output);
};
