#include "result_writer.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <algorithm>

ResultWriter::ResultWriter(const std::string& filepath) : filepath_(filepath) {}

std::string ResultWriter::escapeField(const std::string& s) {
    // Wrap in quotes if field contains comma, quote, or newline
    if (s.find_first_of(",\"\n\r") != std::string::npos) {
        std::string out = "\"";
        for (char c : s) {
            if (c == '"') out += "\"\"";
            else          out += c;
        }
        out += "\"";
        return out;
    }
    return s;
}

std::string ResultWriter::statusToString(SearchStatus s) {
    switch (s) {
        case SearchStatus::ALIVE:          return "Alive";
        case SearchStatus::DECEASED:       return "Deceased";
        case SearchStatus::DATA_NOT_FOUND: return "Data Not Found";
    }
    return "Unknown";
}

bool ResultWriter::write(const std::vector<OutputRecord>& records, std::string& error) {
    std::ofstream file(filepath_);
    if (!file.is_open()) {
        error = "Cannot create output file: " + filepath_;
        return false;
    }

    // Header
    file << "ClientID,FirstName,LastName,County,Status,Detail\n";

    for (const auto& rec : records) {
        file << escapeField(rec.client.client_id)  << ","
             << escapeField(rec.client.first_name) << ","
             << escapeField(rec.client.last_name)  << ","
             << escapeField(rec.client.county)     << ","
             << escapeField(statusToString(rec.result.status)) << ","
             << escapeField(rec.result.detail)     << "\n";
    }

    return true;
}

void ResultWriter::printSummary(const std::vector<OutputRecord>& records) {
    int alive = 0, deceased = 0, not_found = 0;

    std::cout << "\n"
              << "+-----------+----------------------+----------------------+--------------+--------------------------------+\n"
              << "| ClientID  | First Name           | Last Name            | Status       | Detail                         |\n"
              << "+-----------+----------------------+----------------------+--------------+--------------------------------+\n";

    for (const auto& rec : records) {
        std::string status = "";
        switch (rec.result.status) {
            case SearchStatus::ALIVE:          status = "Alive";          ++alive;     break;
            case SearchStatus::DECEASED:       status = "Deceased";       ++deceased;  break;
            case SearchStatus::DATA_NOT_FOUND: status = "Data Not Found"; ++not_found; break;
        }

        // Truncate long strings for display
        auto trunc = [](const std::string& s, size_t max) {
            return s.size() > max ? s.substr(0, max - 2) + ".." : s;
        };

        std::cout << "| " << std::left
                  << std::setw(9)  << trunc(rec.client.client_id, 9)   << " | "
                  << std::setw(20) << trunc(rec.client.first_name, 20) << " | "
                  << std::setw(20) << trunc(rec.client.last_name, 20)  << " | "
                  << std::setw(12) << status                           << " | "
                  << std::setw(30) << trunc(rec.result.detail, 30)     << " |\n";
    }

    std::cout << "+-----------+----------------------+----------------------+--------------+--------------------------------+\n"
              << "\nSummary: "
              << alive     << " Alive | "
              << deceased  << " Deceased | "
              << not_found << " Data Not Found | "
              << records.size() << " Total\n\n";
}
