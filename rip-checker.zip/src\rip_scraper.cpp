#include "rip_scraper.h"
#include <curl/curl.h>
#include <algorithm>
#include <regex>
#include <set>
#include <thread>
#include <chrono>
#include <iostream>

// ---------------------------------------------------------------------------
// Internal struct for a single death notice record parsed from GraphQL JSON
// ---------------------------------------------------------------------------
struct NoticeRecord {
    std::string id;
    std::string firstname;
    std::string surname;
    std::string notice_date;
    std::string county;
    std::string town;
};

// ---------------------------------------------------------------------------
// Curl write callback
// ---------------------------------------------------------------------------
size_t RipScraper::writeCallback(void* contents, size_t size, size_t nmemb, std::string* output) {
    output->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}

RipScraper::RipScraper()  { curl_global_init(CURL_GLOBAL_ALL); }
RipScraper::~RipScraper() { curl_global_cleanup(); }

// ---------------------------------------------------------------------------
// Strip Irish fadas so "Sean" matches "Seán", "O'Brien" matches "Ó'Brien"
// All fada vowels in UTF-8:
//   á=C3A1  é=C3A9  í=C3AD  ó=C3B3  ú=C3BA
//   Á=C381  É=C389  Í=C38D  Ó=C393  Ú=C39A
// ---------------------------------------------------------------------------
std::string RipScraper::stripFadas(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (c == 0xC3 && i + 1 < s.size()) {
            unsigned char n = static_cast<unsigned char>(s[i + 1]);
            switch (n) {
                case 0xA1: out += 'a'; ++i; continue;  // á
                case 0xA9: out += 'e'; ++i; continue;  // é
                case 0xAD: out += 'i'; ++i; continue;  // í
                case 0xB3: out += 'o'; ++i; continue;  // ó
                case 0xBA: out += 'u'; ++i; continue;  // ú
                case 0x81: out += 'a'; ++i; continue;  // Á
                case 0x89: out += 'e'; ++i; continue;  // É
                case 0x8D: out += 'i'; ++i; continue;  // Í
                case 0x93: out += 'o'; ++i; continue;  // Ó
                case 0x9A: out += 'u'; ++i; continue;  // Ú
            }
        }
        out += s[i];
    }
    return out;
}

std::string RipScraper::toLower(const std::string& s) {
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(), ::tolower);
    return out;
}

// Normalize for comparison: strip fadas, lowercase, strip "Co."/"County" prefix
std::string RipScraper::normalizeCounty(const std::string& county) {
    std::string s = toLower(stripFadas(county));
    for (const auto& prefix : {"county ", "co. ", "co."}) {
        if (s.rfind(prefix, 0) == 0) {
            s = s.substr(std::string(prefix).size());
            break;
        }
    }
    size_t start = s.find_first_not_of(" \t");
    size_t end   = s.find_last_not_of(" \t");
    return (start == std::string::npos) ? "" : s.substr(start, end - start + 1);
}

// ---------------------------------------------------------------------------
// First name matching — strips fadas, handles Irish nicknames
// "Sean" matches "Seán", "John" matches "John (Johnny)", etc.
// ---------------------------------------------------------------------------
bool RipScraper::firstNameMatch(const std::string& client_fn, const std::string& notice_fn) {
    std::string cn = toLower(stripFadas(client_fn));
    std::string nn = toLower(stripFadas(notice_fn));
    if (cn == nn) return true;
    if (nn.find(cn) != std::string::npos) return true;
    if (cn.find(nn) != std::string::npos) return true;
    return false;
}

// ---------------------------------------------------------------------------
// Female name filter — returns true if the firstname from Rip.ie appears to
// be female. Used to skip female death notices when all clients are male.
// Covers common Irish/English female first names and their variants.
// ---------------------------------------------------------------------------
bool RipScraper::isFemale(const std::string& firstname) {
    static const std::vector<std::string> female_names = {
        // Irish female names
        "aoife","ciara","niamh","siobhan","sinead","grainne","aisling","caoimhe",
        "roisin","clodagh","fionnuala","nuala","orla","orlaith","sorcha","eimear",
        "eithne","attracta","assumpta","concepta","brid","bridie","brigid","bridget",
        "maura","mairead","caitriona","nora","norah","kathleen","eileen","eilish",
        "maeve","meabh","muireann","ide","ita","treasa","treasa","beibhinn",
        // English/international female names common in Ireland
        "mary","marie","maria","margaret","patricia","anne","ann","anna","annie",
        "elizabeth","eleanor","helen","helena","joan","joanne","johanna",
        "claire","clare","sarah","sara","susan","suzanne","caroline","carol",
        "catherine","kate","katie","karen","linda","laura","lisa","louise",
        "rachel","rebecca","ruth","rose","rosemary","noreen","bernadette",
        "geraldine","jacqueline","sheila","philomena","veronica","valerie",
        "dolores","teresa","theresa","tess","tessa","agnes","alice","amanda",
        "angela","audrey","barbara","beatrice","brenda","carmel","carmelita",
        "dympna","edel","elaine","emma","fiona","grace","hannah","irene",
        "jacinta","janet","jean","jennifer","jessica","julia","julie","june",
        "kim","leah","lorraine","lucy","lynda","lynn","martina","michelle",
        "monica","nadine","nicola","olive","pamela","paula","pauline","peggy",
        "rita","sandra","sharon","sheelagh","shirley","siobhain","stacey",
        "stephanie","tina","tracy","tracey","una","ursula","wendy","yvonne"
    };

    // Extract the base first name (before any space or bracket)
    std::string base = toLower(stripFadas(firstname));
    size_t sp = base.find_first_of(" (");
    if (sp != std::string::npos) base = base.substr(0, sp);

    for (const auto& f : female_names) {
        if (base == f) return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// HTTP POST (used for GraphQL)
// ---------------------------------------------------------------------------
std::string RipScraper::httpPost(const std::string& url, const std::string& body) {
    CURL* curl = curl_easy_init();
    if (!curl) return "";

    std::string response;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, "Origin: https://rip.ie");
    headers = curl_slist_append(headers, "Referer: https://rip.ie/");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT,
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        std::cerr << "  [curl error] " << curl_easy_strerror(res) << "\n";
        response.clear();
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

// ---------------------------------------------------------------------------
// Build the GraphQL request body for a surname search on a given page
//
// Endpoint: POST https://rip.ie/api/graphql
// Query:    searchDeathNoticesForList(query: ListInput!, isTiledView: Boolean!)
// Fields returned: id, firstname, surname, createdAt, county.name, town.name
// ---------------------------------------------------------------------------
std::string RipScraper::buildQuery(const std::string& surname, int page) {
    // Escape any double-quotes in the surname just in case
    std::string safe;
    for (char c : surname) {
        if (c == '"' || c == '\\') safe += '\\';
        safe += c;
    }

    return
        "{\"query\":\"{ searchDeathNoticesForList("
        "query: { search: \\\"" + safe + "\\\", page: " + std::to_string(page) + " }, "
        "isTiledView: false) { "
        "page nextPage "
        "records { id firstname surname createdAt "
        "county { name } town { name } } } }\"}";
}

// ---------------------------------------------------------------------------
// Parse death notice records from the GraphQL JSON response.
//
// Expected shape (abbreviated):
//   {"data":{"searchDeathNoticesForList":{
//     "nextPage": true,
//     "records":[
//       {"id":624712,"firstname":"DAN","surname":"MURPHY",
//        "createdAt":"2026-03-15T21:49:39.760+00:00",
//        "county":{"name":"Kerry"},"town":{"name":"Milltown"}},
//       ...
//     ]}}}
//
// NOTE: If Rip.ie changes their GraphQL schema, adjust the regex below.
// ---------------------------------------------------------------------------
static bool parseGraphQL(const std::string& json,
                          std::vector<NoticeRecord>& out,
                          bool& next_page) {
    if (json.empty()) return false;

    // Check for errors
    if (json.find("\"errors\"") != std::string::npos &&
        json.find("\"data\"") == std::string::npos) {
        return false;
    }

    // Extract nextPage
    next_page = (json.find("\"nextPage\":true") != std::string::npos);

    // Match individual records from the records array
    // Pattern matches objects in the records array returned by the GraphQL query.
    static const std::regex re(
        R"rgx("id":(\d+),"firstname":"([^"]+)","surname":"([^"]+)","createdAt":"(\d{4}-\d{2}-\d{2})T[^"]*","county":\{"name":"([^"]+)"\},"town":\{"name":"([^"]+)"\})rgx"
    );

    std::set<std::string> seen;
    auto it  = std::sregex_iterator(json.begin(), json.end(), re);
    auto end = std::sregex_iterator();
    for (; it != end; ++it) {
        const std::smatch& m = *it;
        std::string id = m[1].str();
        if (!seen.insert(id).second) continue;

        NoticeRecord rec;
        rec.id          = id;
        rec.firstname   = m[2].str();
        rec.surname     = m[3].str();
        rec.notice_date = m[4].str();
        rec.county      = m[5].str();
        rec.town        = m[6].str();
        out.push_back(rec);
    }
    return true;
}

// ---------------------------------------------------------------------------
// Public search entry point
//
// Strategy:
//   1. POST a GraphQL query to https://rip.ie/api/graphql searching by surname.
//   2. Parse the returned records and compare name + county client-side.
//   3. Paginate (up to MAX_PAGES) if no match found and more pages exist.
//
// Fada handling: both the CSV data and Rip.ie data have fadas stripped before
// comparison, so "Sean" matches "Seán" and "O Brien" matches "Ó'Brien".
// ---------------------------------------------------------------------------
SearchResult RipScraper::search(const std::string& first_name,
                                 const std::string& last_name,
                                 const std::string& county) {
    if (first_name.empty() || last_name.empty()) {
        return {SearchStatus::DATA_NOT_FOUND, "Missing first or last name"};
    }

    static const int MAX_PAGES = 10;  // 10 × 40 records = up to 400 checked
    static const char* GRAPHQL_URL = "https://rip.ie/api/graphql";

    // Strip parenthetical from last name to get base surname for searching.
    // Also extract maiden name if present (née ...) for fallback search.
    // e.g. "Caputo (née Malone)" -> base="Caputo", maiden="Malone"
    //      "Andrews (née Kavanagh)" -> base="Andrews", maiden="Kavanagh"
    std::string base_surname;
    std::string maiden_name;
    {
        auto paren = last_name.find('(');
        if (paren != std::string::npos) {
            base_surname = last_name.substr(0, paren);
            size_t e = base_surname.find_last_not_of(" \t");
            if (e != std::string::npos) base_surname = base_surname.substr(0, e + 1);

            // Extract maiden name from "(née ...)" or "(nee ...)"
            std::string inside = last_name.substr(paren + 1);
            std::string inside_lower = toLower(stripFadas(inside));
            size_t nee = inside_lower.find("nee ");
            if (nee != std::string::npos) {
                maiden_name = inside.substr(nee + 4);
                size_t close = maiden_name.find(')');
                if (close != std::string::npos) maiden_name = maiden_name.substr(0, close);
                e = maiden_name.find_last_not_of(" \t)");
                if (e != std::string::npos) maiden_name = maiden_name.substr(0, e + 1);
            }
        } else {
            base_surname = last_name;
        }
    }

    std::string norm_county = normalizeCounty(county);

    // Helper lambda: search one surname across pages, with optional county filter.
    // Returns a found SearchResult or an empty one (status ALIVE) if not found.
    auto searchBySurname = [&](const std::string& surname,
                                bool require_county) -> SearchResult {
        std::string norm_sn = toLower(stripFadas(surname));

        for (int page = 1; page <= MAX_PAGES; ++page) {
            std::string body = buildQuery(surname, page);
            std::string json = httpPost(GRAPHQL_URL, body);

            std::vector<NoticeRecord> records;
            bool next_page = false;

            if (!parseGraphQL(json, records, next_page))
                return {SearchStatus::DATA_NOT_FOUND, "GraphQL request failed"};

            if (records.empty() && page == 1)
                return {SearchStatus::ALIVE, "No death notices found for this name"};

            for (const auto& rec : records) {
                if (toLower(stripFadas(rec.surname)) != norm_sn) continue;
                if (isFemale(rec.firstname)) continue;   // skip female notices
                if (!firstNameMatch(first_name, rec.firstname)) continue;
                if (require_county && !norm_county.empty()) {
                    if (normalizeCounty(rec.county) != norm_county) continue;
                }

                SearchResult result;
                result.status         = SearchStatus::DECEASED;
                result.match_name     = rec.firstname + " " + rec.surname;
                result.match_location = rec.town + ", Co. " + rec.county;
                result.match_date     = rec.notice_date;
                result.detail         = "Death notice found"
                                        " | Notice date: " + rec.notice_date +
                                        " | Location: "    + result.match_location;
                if (!require_county && !norm_county.empty())
                    result.detail += " (county in CSV unverified)";
                return result;
            }

            if (!next_page) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(rate_limit_ms_));
        }
        return {SearchStatus::ALIVE, "No matching death notice found"};
    };

    std::cout << "  Querying: " << first_name << " " << base_surname;
    if (!county.empty()) std::cout << " [" << county << "]";
    std::cout << "\n";

    // Pass 1: search by base surname with county
    SearchResult result = searchBySurname(base_surname, true);
    if (result.status == SearchStatus::DECEASED) return result;
    if (result.status == SearchStatus::DATA_NOT_FOUND) return result;

    // Pass 2: search by base surname WITHOUT county (county in CSV may be wrong)
    if (!norm_county.empty()) {
        result = searchBySurname(base_surname, false);
        if (result.status == SearchStatus::DECEASED) return result;
    }

    // Pass 3: search by maiden name (she may be listed under née name on Rip.ie)
    if (!maiden_name.empty()) {
        std::cout << "  Retrying with maiden name: " << maiden_name << "\n";
        result = searchBySurname(maiden_name, true);
        if (result.status == SearchStatus::DECEASED) return result;

        // Pass 4: maiden name without county
        if (!norm_county.empty()) {
            result = searchBySurname(maiden_name, false);
            if (result.status == SearchStatus::DECEASED) return result;
        }
    }

    return {SearchStatus::ALIVE, "No matching death notice found"};
}
